﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApplication2.Migrations
{
    public partial class c1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_tbl_StateName",
                table: "tbl_StateName");

            migrationBuilder.RenameTable(
                name: "tbl_StateName",
                newName: "tbl_State");

            migrationBuilder.AlterColumn<string>(
                name: "StateName",
                table: "tbl_State",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddPrimaryKey(
                name: "PK_tbl_State",
                table: "tbl_State",
                column: "StateId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_tbl_State",
                table: "tbl_State");

            migrationBuilder.RenameTable(
                name: "tbl_State",
                newName: "tbl_StateName");

            migrationBuilder.AlterColumn<int>(
                name: "StateName",
                table: "tbl_StateName",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddPrimaryKey(
                name: "PK_tbl_StateName",
                table: "tbl_StateName",
                column: "StateId");
        }
    }
}
