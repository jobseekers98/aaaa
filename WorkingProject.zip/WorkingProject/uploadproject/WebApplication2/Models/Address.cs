﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication2.Models
{
   
    public class Address
    {
        [Key]
        public int Id { get; set; }

        public string Postal { get; set; }

        public string City { get; set; }

        public string District { get; set; }

        public int StateId { get; set; }

        public string country { get; set; }

        public string Latitude { get; set; }

        public string Longitude { get; set; }
    }

    public class AddressVM
    {
        [Key]
        public int Id { get; set; }

        public string Postal { get; set; }

        public string City { get; set; }

        public string District { get; set; }

        public int StateId { get; set; }

        public string country { get; set; }

        public string Latitude { get; set; }

        public string Longitude { get; set; }
       public List<StateMaster> StateDropDownList { get; set; }
        //public List<StateMaster> StateDropDownList { get; set; } = new List<StateMaster>();
    };
}
