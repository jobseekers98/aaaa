﻿

var a;
function getlocation() {
    var places = new google.maps.places.Autocomplete(document.getElementById('txtLocation'));
    google.maps.event.addListener(places, 'place_changed', function () {
        var place = places.getPlace();
        var latitude = place.geometry.location.lat();
        var longitude = place.geometry.location.lng();

        var country;
        var city;
        var district;
        var Postal;
        var State;
        debugger;
        for (var i = 0; i < place.address_components.length; i++) {
            var find = false;
            for (var j = 0; j < place.address_components[i].types.length; j++) {
                if (place.address_components[i].types[j] == "postal_code") {
                    Postal = place.address_components[i].long_name;
                }

                else if (place.address_components[i].types[j] == "locality") {
                    city = place.address_components[i].long_name;
                }

                else if (place.address_components[i].types[j] == "administrative_area_level_2") {

                    district = place.address_components[i].long_name;
                }
                else if (place.address_components[i].types[j] == "administrative_area_level_1") {
                    State = place.address_components[i].long_name;
                    //alert(State);
                    if (State !== null) {
                        $("#drpList option:contains(" + State.toUpperCase() + ")").attr('selected', 'selected');
                        //$("#drpEmpList").val(State).attr("selected", "selected");
                        // $("#drpList").val(State);
                        //$('select[name^="salesrep"] option[value="Bruce Jones"]').attr("selected", "selected");
                    }
                }
                else if (place.address_components[i].types[j] == "country") {
                    country = place.address_components[i].long_name;
                }
            }
        }

        debugger;
        $("#idPostal").val(Postal);
        $("#idCity").val(city);
        $("#idDistrict").val(district);
        // $("#drpEmpList").text(State);
        $("#idcountry").val(country);
        $("#Latitude").val(latitude);
        $("#Longitude").val(longitude);
    });
}


function submitStudent()
{
    debugger;
    var data = $("#studenteForm").serialize();
    console.log(data);
    alert(data);
    $.ajax({
        type: 'POST',
        url: '/Home/TestAddress',
        contentType: 'application/x-www-form-urlencoded; charset=UTF-8', // when we use .serialize() this generates the data in query string format. this needs the default contentType (default content type is: contentType: 'application/x-www-form-urlencoded; charset=UTF-8') so it is optional, you can remove it
        data: data,
        success: function (result) {
            alert('Successfully received Data ');
            console.log(result);
        },
        error: function () {
            alert('Failed to receive the Data');
            console.log('Failed ');
        }
    })
}



//var a;
//function getlocation() {
//    var places = new google.maps.places.Autocomplete(document.getElementById('txtLocation'));
//    google.maps.event.addListener(places, 'place_changed', function () {
//        var place = places.getPlace();

//        var address = place.formatted_address;
//        var latitude = place.geometry.location.lat();
//        var longitude = place.geometry.location.lng();
//        var mesg = "Address: " + address;
//        mesg += "\nLatitude: " + latitude;
//        mesg += "\nLongitude: " + longitude;
//        a = place;
//        //alert(mesg);
//        //var cityname = a.address_components[0].long_name;
//        //var districtname = a.address_components[1].long_name;
//        //var Statename = a.address_components[2].long_name;
//        //var Countryname = a.address_components[3].long_name;


//        //var msgg = "city=" + cityname + "\n District=" + districtname + "\n State=" + Statename + "\n Contry=" + Countryname;

//        //msgg = msgg + "\n lat=" + latitude;
//        //msgg = msgg + "\n lon=" + longitude;
//        var state;
//        var city;
//        var country;
//        var messages = "";
//        for (var i = 0; i < place.address_components.length; i++) {
//            var find = false;
//            for (var j = 0; j < place.address_components[i].types.length; j++) {
//                if (place.address_components[i].types[j] == "postal_code") {
//                    //alert(place.address_components[i].long_name);
//                    messages = messages + "\nPostal Code  = " + place.address_components[i].long_name
//                    find = true
//                    break;
//                }
//            }
//            if (find) {
//                break
//            }
//        }


//        for (var i = 0; i < place.address_components.length; i++) {
//            var find = false;
//            for (var j = 0; j < place.address_components[i].types.length; j++) {
//                if (place.address_components[i].types[j] == "locality") {
//                    //alert(place.address_components[i].long_name);
//                    messages = messages + "\nCity = " + place.address_components[i].long_name
//                    find = true
//                    break;
//                }
//            }
//            if (find) {
//                break
//            }
//        }
//        for (var i = 0; i < place.address_components.length; i++) {
//            var find = false;
//            for (var j = 0; j < place.address_components[i].types.length; j++) {
//                if (place.address_components[i].types[j] == "administrative_area_level_2") {
//                    //alert(place.address_components[i].long_name);
//                    messages = messages + "\n District = " + place.address_components[i].long_name
//                    find = true
//                    break;
//                }
//            }
//            if (find) {
//                break
//            }
//        }

//        for (var i = 0; i < place.address_components.length; i++) {
//            var find = false;
//            for (var j = 0; j < place.address_components[i].types.length; j++) {
//                if (place.address_components[i].types[j] == "administrative_area_level_1") {
//                    //alert(place.address_components[i].long_name);
//                    messages = messages + "\n State = " + place.address_components[i].long_name
//                    find = true
//                    break;
//                }
//            }
//            if (find) {
//                break
//            }
//        }
//        for (var i = 0; i < place.address_components.length; i++) {
//            var find = false;
//            for (var j = 0; j < place.address_components[i].types.length; j++) {
//                if (place.address_components[i].types[j] == "country") {
//                    //alert(place.address_components[i].long_name);
//                    messages = messages + "\n country = " + place.address_components[i].long_name
//                    find = true
//                    break;
//                }
//            }
//            if (find) {
//                break
//            }
//        }

//        alert(messages)
//    });
//}

   