﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class DemoController : Controller
    {
        private readonly ApplicationContext dbcontext;

        public DemoController(ApplicationContext _dbContext) 
        {

            dbcontext = _dbContext;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult TestValidation() 
        {
            Student model = new Student();

            return View(model);

        }

        [HttpPost]
        public IActionResult TestValidation(Student model)
        {

            dbcontext.tbl_Student.Add(model);
            dbcontext.SaveChanges();
            return View(model);

        }


    }
}
